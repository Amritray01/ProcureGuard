===========================================================
PROCUREMENT INVOICE & CONTRACT AUDITOR - SAMPLE DOCUMENTS
===========================================================

This archive contains verified procurement benchmark documents with
proper chronological date sequences, physical addresses, and ground truth labels:

1. invoices/
   - INV-101_Clean_Approved.pdf: Clean 3-way match against PO-2026-001
   - INV-102_Price_Variance.pdf: Unit price drift from $600 to $750 (PO-2026-002)
   - INV-103_Missing_Fields_HITL.pdf: Scanned / missing header fields triggering HITL
   - INV-105_Contract_Violation_Surcharge.pdf: Banned freight fee violation (PO-2026-001)

2. ERP Order Documents (CSV File Format):
   - purchase_orders.csv:
     Relational table of authorized Purchase Orders with addresses and issuance dates.
   - goods_receipts.csv:
     Warehouse physical receipt proof table of good orders with verified delivery dates.

3. contracts.json:
   - Master Service Agreement (MSA) legal clauses indexed for Vector RAG.

4. ground_truth/:
   - Expected decisions and reason codes for deterministic benchmark validation.

To audit, upload files in the Web Cockpit or via POST /api/session/start
