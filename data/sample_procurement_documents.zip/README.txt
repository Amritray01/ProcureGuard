===========================================================
PROCUREMENT INVOICE & CONTRACT AUDITOR - SAMPLE DOCUMENTS
===========================================================

This archive contains verified procurement benchmark documents with
proper chronological date sequences, physical addresses, and ground truth labels:

1. invoices/
   - INV-101_Clean_Approved.pdf: Clean 3-way match against PO-2026-001
   - INV-102_Price_Variance.pdf: Unit price drift from $600 to $750 (PO-2026-002)
   - INV-103_Missing_Fields_HITL.pdf: Scanned / missing header fields triggering HITL
   - INV-105_Contract_Violation_Surcharge.pdf: Banned freight fee violation (PO-2026-001)

2. purchase_orders.json:
   - Master authorized Purchase Orders with vendor addresses and issuance dates

3. goods_receipts.json:
   - Warehouse physical receipt proofs with delivery dates

4. contracts.json:
   - Master Service Agreement (MSA) legal clauses indexed for Vector RAG

5. ground_truth/:
   - Expected decisions and reason codes for deterministic benchmark validation

To audit, upload any PDF in the Cockpit or use POST /api/audit/pdf
